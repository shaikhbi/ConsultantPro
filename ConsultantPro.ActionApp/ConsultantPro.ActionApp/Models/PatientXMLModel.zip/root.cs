﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace ConsultantPro.ActionApp.Models
{

    public class root
    {
        [XmlAttribute]
        public string command { get; set; }

        public PatientXMLModel patient { get; set; }
    }
}