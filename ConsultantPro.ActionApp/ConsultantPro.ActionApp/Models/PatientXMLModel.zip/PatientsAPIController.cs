﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ConsultantPro.ActionApp.Models;

namespace ConsultantPro.ActionApp.Controllers
{
    public class PatientsAPIController : ApiController
    {
        private ConsultantContext db = new ConsultantContext();

        // GET: api/PatientsAPI
        public IQueryable<Patient> GetPatients()
        {
            return db.Patients;
        }

        // GET: api/PatientsAPI/5
        [ResponseType(typeof(Patient))]
        public IHttpActionResult GetPatient(short id)
        {
            Patient patient = db.Patients.Find(id);
            if (patient == null)
            {
                return NotFound();
            }

            return Ok(patient);
        }

        // PUT: api/PatientsAPI/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutPatient(short id, Patient patient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != patient.PatientId)
            {
                return BadRequest();
            }

            db.Entry(patient).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PatientExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        [HttpPost]
        [Route("api/ExecuteCommand")]
        public IHttpActionResult ExecuteCommand(root rtCommand)
        {
            IHttpActionResult view = null;
            string[] cmd = rtCommand.command.Split('.');
            if (cmd[0].Equals("Patient"))
            {
                if (cmd[1].Equals("Save"))
                {
                    view = PostPatient(rtCommand.patient);
                }
            }

            return view;
        }

        // POST: api/PatientsAPI
        [ResponseType(typeof(Patient))]
        public IHttpActionResult PostPatient(PatientXMLModel _patient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            Patient patient = new Patient();

            // for general info
            string[] generalInfo = _patient.o.Split(',');

            patient.PatientId = Convert.ToInt16(generalInfo[0]);
            patient.PatientType = Convert.ToInt16(generalInfo[1]);
            patient.status = Boolean.Parse(generalInfo[2]);
            patient.DateOfBirth = DateTime.Now; ;

            if (_patient.contacts != null)
            {
                List<string> list = new List<string>();
                string[] secs = _patient.contacts.Split('|');

                foreach (string sec in secs)
                {
                    string[] info = sec.Split(',');
                    switch (info[0])
                    {
                        case "1":
                            patient.phone = info[1];
                            break;
                        case "2":
                            patient.office = info[1];
                            break;
                        case "3":
                            patient.cell = info[1];
                            break;
                        case "4":
                            patient.fax = info[1];
                            break;
                        case "5":
                            patient.email = info[1];
                            break;
                    }
                }
            }



            db.Patients.Add(patient);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = patient.PatientId }, patient);
        }

        // DELETE: api/PatientsAPI/5
        [ResponseType(typeof(Patient))]
        public IHttpActionResult DeletePatient(short id)
        {
            Patient patient = db.Patients.Find(id);
            if (patient == null)
            {
                return NotFound();
            }

            db.Patients.Remove(patient);
            db.SaveChanges();

            return Ok(patient);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool PatientExists(short id)
        {
            return db.Patients.Count(e => e.PatientId == id) > 0;
        }
    }
}