namespace ConsultantPro.ActionApp.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Patient
    {
        public short PatientId { get; set; }

        public short PatientType { get; set; }
        
        public bool? status { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string phone { get; set; }

        public string office { get; set; }

        public string cell { get; set; }

        public string fax { get; set; }

        public string email { get; set; }
    }
}
